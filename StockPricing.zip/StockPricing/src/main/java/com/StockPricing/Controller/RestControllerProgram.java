package com.StockPricing.Controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.StockPricing.Dao.CompanyDao;
import com.StockPricing.Dao.IPODetailsDao;
import com.StockPricing.Dao.StockDao;
import com.StockPricing.model.Company;
import com.StockPricing.model.IPODetails;
import com.StockPricing.model.Stock;

@RestController
public class RestControllerProgram {
	@Autowired
	CompanyDao companyDao;

	@Autowired
	IPODetailsDao ipoDetailsDao;

	@Autowired
	StockDao stockDao;

	@GetMapping(value = "companies/sectorId/{sectorId}")
	public List<Company> findBySectorId(@PathVariable int sectorId) {

		List<Company> company = companyDao.findBySectorId(sectorId);
		return company;
	}

	@GetMapping(value = "companies/companyCode/{companyCode}")
	/*
	 * public IPODetails findByCompanyCode(@PathVariable int companyCode) {
	 * 
	 * return ipoDetailsDao.findByCompanyCode(companyCode); }
	 */

	public List<IPODetails> findByCompanycode(@PathVariable int companyCode) {

		List<IPODetails> ipoDetails = ipoDetailsDao.findByCompanyCode(companyCode);
		return ipoDetails;
	}

	@GetMapping(value = "companies/search/{letter}")
	public List<Company> findByCompanyName(@PathVariable String letter) {

		List<Company> company = companyDao.findBycompanyName(letter);

		return company;
	}

	@GetMapping(value = "companies/stockPrice/{companyId}")
	public List<Stock> findByCompanyId(@PathVariable int companyId) {

		List<Stock> stock = stockDao.findByCompanyId(companyId);
		return stock;
	}

	@GetMapping(value = "companies/stockPrice/sector/{sectorname}")
	public String[] finfByStockId(@PathVariable String sectorname) {

		return stockDao.findByStockId(sectorname);

	}

	@GetMapping(value = "companies/stockPrice/{date1}/{date2}")
	public List<Stock> findByDate(@PathVariable("date1") Date date1, @PathVariable("date2") Date date2) {
		List<Stock> stock = (List<Stock>) stockDao.findByDate(date1, date2);
		return stock;
	}

	@GetMapping("/listofcompaniesinsector/{sectorid}/{date1}/{date2}")
	Double companySectorList(@PathVariable("sectorid") int sectorid, @PathVariable("date1") Date date1,
			@PathVariable("date2") Date date2) {
		Double sum = 0.0;
		int companyCode[] = companyDao.findSectorList(sectorid);
		List<Double> stockPriceList = new ArrayList<>();
		for (int i = 0; i < companyCode.length; i++) {
			System.out.println(companyCode[i]);
			stockDao.findBycompanyId(companyCode[i], date1, date2).forEach(stockPriceList::add);
			;
		}

		for (Double price : stockPriceList) {
			sum = sum + price;
		}
		return sum;
	}

}
