package com.StockPricing.Dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.StockPricing.model.User;

public interface UserDao extends JpaRepository<User, Integer> {

	List<User> findByUsername(String username);
	/*
	 * boolean loginUser(User user) throws SQLException;
	 */
	/*
	 * public int registerUser(User user) throws SQLException;
	 * 
	 * public boolean loginUser(User user) throws SQLException;
	 */
}
