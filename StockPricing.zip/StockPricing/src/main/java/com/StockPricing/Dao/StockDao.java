package com.StockPricing.Dao;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.StockPricing.model.Company;
import com.StockPricing.model.Sector;
import com.StockPricing.model.Stock;

public interface StockDao extends JpaRepository<Stock, Integer> {
	public List<Stock> findByCompanyId(int companyId);

	@Query("select s from Stock s where s.date between :date1 and :date2")
	public List<Stock> findByDate(@Param("date1") Date date1, @Param("date2") Date date2);

	@Query("select s.currentPrice from Stock s where s.companyId=:companyCode and s.date between :date1 and :date2")
	public List<Double> findBycompanyId(@Param(value = "companyCode") int companyCode,
			@Param(value = "date1") Date date1, @Param(value = "date2") Date date2);

	@Query(value = "select  s.current_price,c.company_name  FROM stock_price_details as s JOIN company as c ON s.company_id=c.company_code where c.sector_id in (select sector_id from sectors where sector_name= :sectorname)", nativeQuery = true)
	public String[] findByStockId(@Param("sectorname") String sectorname);

}
