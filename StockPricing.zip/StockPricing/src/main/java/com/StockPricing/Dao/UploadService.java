package com.StockPricing.Dao;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.StockPricing.model.Stock;

public interface UploadService {
	public List<Stock> upload(MultipartFile file) throws Exception;
}
