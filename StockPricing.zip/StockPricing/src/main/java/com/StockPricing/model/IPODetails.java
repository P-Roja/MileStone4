package com.StockPricing.model;

import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "ipo_planned")
public class IPODetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ipo_id")
	private int ipoId;

	/*
	 * @OneToOne(cascade=CascadeType.ALL)
	 * 
	 * @JoinColumn(name="company_code") private Company company;
	 */

	@Column(name = "company_code")
	private int companyCode;

	@Column(name = "Stockexchange_code")
	@NotNull(message = "price")
	private int stockExchange;

	@Column(name = "price_per_share")
	//@NotNull(message = "Price Should not be Empty")
	private double priceperShare;

	@Column(name = "remarks")

	//@Pattern(regexp = "^[A-Za-z]+$", message = "Remarks should not contain numbers")
	private String remarks;

	@Column(name = "total_no_of_shares")
	//@NotNull
	private int totalShares;

	@Column(name = "open_date_time")

	private Date openDateTime;

	public int getIpoId() {
		return ipoId;
	}

	public void setIpoId(int ipoId) {
		this.ipoId = ipoId;
	}

	public int getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(int companyCode) {
		this.companyCode = companyCode;
	}

	public int getStockExchange() {
		return stockExchange;
	}

	public void setStockExchange(int stockExchange) {
		this.stockExchange = stockExchange;
	}

	public int getTotalShares() {
		return totalShares;
	}

	public void setTotalShares(int totalShares) {
		this.totalShares = totalShares;
	}

	public Date getOpenDateTime() {
		return openDateTime;
	}

	public void setOpenDateTime(Date openDateTime) {
		this.openDateTime = openDateTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public double getPriceperShare() {
		return priceperShare;
	}

	public void setPriceperShare(double priceperShare) {
		this.priceperShare = priceperShare;
	}

	@Override
	public String toString() {
		return "IPODetails [ipoId=" + ipoId + ", companyCode=" + companyCode + ", stockExchange=" + stockExchange
				+ ", priceperShare=" + priceperShare + ", remarks=" + remarks + ", totalShares=" + totalShares
				+ ", openDateTime=" + openDateTime + "]";
	}

	/*
	 * @Override public String toString() { return "IPODetails [ipoId=" + ipoId
	 * + ", company=" + company + ", stockExchange=" + stockExchange +
	 * ", priceperShare=" + priceperShare + ", remarks=" + remarks +
	 * ", totalShares=" + totalShares + ", openDateTime=" + openDateTime + "]";
	 * }
	 */
	/*
	 * public Company getCompany() { return company; }
	 * 
	 * public void setCompany(Company company) { this.company = company; }
	 */

}
