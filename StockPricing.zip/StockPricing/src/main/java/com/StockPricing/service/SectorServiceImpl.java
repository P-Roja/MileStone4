package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StockPricing.Dao.SectorDao;
import com.StockPricing.model.Company;
import com.StockPricing.model.Sector;

@Service
public class SectorServiceImpl implements SectorService {
	@Autowired
	SectorDao sectorDao;

	@Override
	public List<Sector> getSectorList() throws SQLException {
		return sectorDao.findAll();
	}

	@Override
	public void insertSector(Sector sector) throws SQLException {
		sectorDao.save(sector);

	}

	@Override
	public void updateSector(Sector sector) throws SQLException {
		sectorDao.save(sector);

	}

	@Override
	public Sector fetchSectorUpdate(int sectorId) throws SQLException, ClassNotFoundException {
		return sectorDao.findOne(sectorId);
	}

}
