package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StockPricing.Dao.IPODetailsDao;
import com.StockPricing.model.IPODetails;

@Service
public class IPOServiceImpl implements IPOService {

	@Autowired
	IPODetailsDao ipoDao;

	@Override
	public List<IPODetails> getIPOList() throws SQLException {

		return ipoDao.findAll();
	}

	@Override
	public void insertIPO(IPODetails ipoDetails) throws SQLException {
		ipoDao.save(ipoDetails);

	}

	@Override
	public void updateIPODetails(IPODetails ipoDetails) throws SQLException {
		System.out.println(ipoDetails.getPriceperShare());
		ipoDao.save(ipoDetails);

	}

	@Override
	public IPODetails fetchUpdate(int IPOId) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return ipoDao.getOne(IPOId);
	}

}
