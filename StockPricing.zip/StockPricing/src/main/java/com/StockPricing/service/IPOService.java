package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import com.StockPricing.model.IPODetails;
import com.StockPricing.model.Sector;

public interface IPOService {
	public List<IPODetails> getIPOList() throws SQLException;

	public void insertIPO(IPODetails ipoDetails) throws SQLException;

	public void updateIPODetails(IPODetails ipoDetails) throws SQLException;

	public IPODetails fetchUpdate(int IPOId) throws SQLException, ClassNotFoundException;

}
